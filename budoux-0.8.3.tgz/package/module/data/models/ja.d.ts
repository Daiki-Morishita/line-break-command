export declare const model: {
    [key: string]: {
        [key: string]: number;
    };
};
